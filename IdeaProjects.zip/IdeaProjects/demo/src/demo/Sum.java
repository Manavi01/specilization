package demo;

import java.util.Scanner;



public class Sum {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int count,i;
        int []a=new int[20];
        for( i=1;i<=10;i++)
        {
            a[i]=sc.nextInt();
        }
        for(i=1;i<=20;i++)
        {
            count=0;
            for(int j=1;j<=10;j++)
            {
                if(a[i]==a[j])
                {
                    count++;
                    if(count==5)
                    {

                        System.out.println(a[i]);
                    }
                }
            }



        }



    }
}