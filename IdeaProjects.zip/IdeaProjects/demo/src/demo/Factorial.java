package demo;

import java.util.Scanner;
public class Factorial {
    private static void factorial(int num) {
        int i;
        int fact=1;
        for(i=1;i<=num;i++)
        {
            fact=fact*i;
        }
        System.out.println(fact);

    }
    public static void main(String args[])
    {
        Scanner sc =new Scanner(System.in);
        int num=sc.nextInt();
        factorial(num);



    }

}