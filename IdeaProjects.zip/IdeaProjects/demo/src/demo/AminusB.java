package demo;

public class AminusB {
    public static void main(String[] args) {
        int a[] = {100, 45, 67, 89, 500, 200};// 6 7
        int b[] = {100, 200, 300, 400, 500, 700, 900};
        int[] aib = new int[a.length + b.length];
        int ele=0;
        for(int i=0;i<a.length;i++) {
            boolean elePresent = isElementPresent(b,a[i]);
            if(elePresent == false) {
                aib[ele++] = a[i];
            }
        }
        for(int i=0;i<ele;i++) {
            System.out.print(aib[i]+" ");
        }
    }
    static boolean isElementPresent(int[] ab,int target) {
        boolean res = false;
        for(int i=0;i<ab.length;i++) {
            if(ab[i] == target) {
                res = true;
                break;
            }
        }
        return res;
    }
}
