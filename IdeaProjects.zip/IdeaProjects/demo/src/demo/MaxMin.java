package demo;
import java.util.Scanner;
public class MaxMin {
    public static int maxi(int num1, int num2, int num3)
    {
        if(num1>num2&&num1>num3) return num1;
        else if(num2>num3) return num2;
        else return num3;
    }

    public static int mini(int num1, int num2, int num3)
    {
        Scanner sc=new Scanner(System.in);
        if(num1<num2&&num1<num3) return num1;
        else if(num2<num3) return num2;
        else return num3;
    }



    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.print("enter the number1");
        int num1=sc.nextInt();
        System.out.print("enter the number2");
        int num2=sc.nextInt();
        System.out.print("enter the number3");
        int num3=sc.nextInt();
        System.out.println("max num"+maxi(num1,num2,num3));
        System.out.println("min num"+mini(num1,num2,num3));
    }
}
