package demo;

public interface Bank {

    void withDraw(int amount);
    void deposit(int amount);
    void showBalance();

}