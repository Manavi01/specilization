package demo;

import java.util.Scanner;
public class Product {
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.print("input first number:");
        int num1 = in.nextInt();
        System.out.print("input second number:");
        int num2 = in.nextInt();
        System.out.println(num1 + "x" + num2 + "=" + num1 * num2);
    }
}
