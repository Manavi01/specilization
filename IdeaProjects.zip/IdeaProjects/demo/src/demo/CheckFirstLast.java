package demo;

import java.util.Scanner;

public class CheckFirstLast {
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        int num = sc.nextInt();
        int a;
        int r;
        r=num%10;//7
        a=num/10000;
        if(a==r) {
            System.out.println("they are equal");
        }
        else{
            System.out.println("not equal");
        }
        }
    }

