package demo;


import java.util.Scanner;
public class Vote {
    private static void eligile(int age) {
        if(age>=18) System.out.println("Can vote");
        else System.out.println("Cant vote");
    }
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter age");
        int age=sc.nextInt();
        eligile(age);



    }
}
