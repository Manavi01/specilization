package demo;
import java.util.Scanner;
public class Find {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int no, first, second, third, fourth, Increased_no;

        System.out.println("Type any 4-digit no. : \n");

        no = sc.nextInt();

        first = no / 1000;

        no = no % 1000;

        second = no / 100;

        no = no % 100;

        third = no / 10;

        fourth = no % 10;

        Increased_no = (first + 3) * 1000 + (second + 3) * 100 + (third + 3) * 10 + (fourth + 3);

        System.out.println("Increased No. is " + Increased_no);
    }
}