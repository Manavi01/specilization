package demo;

import java.util.Scanner;
public class Passfail {
    private static String grade(int marks) {
        if(marks>=91) return "AA";
        if(marks>=81) return "AB";
        if(marks>=71) return "BB";
        if(marks>=61) return "BC";
        if(marks>=51) return "CD";
        if(marks>=41) return "DD";
        else return "Fail";
    }
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        int marks= sc.nextInt();
        System.out.println("Grade for marks"+" "+marks+" "+grade(marks));
    }
}