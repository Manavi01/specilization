package crud;
public class Pattern2 {
    public static void main(String[] args)
    {
        char [] data={'A','B','C','D','E'};
        int a=65;
        for(int i=0,k=0;i<5;i++)
        {
            for(int c=0;c<=i;c++)
            {
                System.out.print((char)(k+a)+" ");
                k++;
            }
            System.out.println("\n");
        }
    }
}
