package crud;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class StudentMenu {
    static Scanner sc=new Scanner(System.in);
    static List studentList= new ArrayList<Student>();
    static Student student;
    public static void main(String[] args)
    {
        int choice=0;
        do {
            System.out.println("Enter your choice");
            System.out.println("1.Insert student\n2.Display student\n3.Search student\n4.Update student\n5.Remove student");
            System.out.println("6.Exit(press -1)");
            choice = sc.nextInt();
            switch (choice) {
                case 1:
                    readStudent();
                    break;
                case 2:
                    System.out.println(studentList);
                    break;
                case 3:
                    searchstudent(studentList);
                    break;
                case 4:
                    updatestudent(studentList);
                    break;
                case 5:
                    removestudent(studentList);
            }
        }while(choice!=-1);
    }
    private static void removestudent(List<Student> studentList) {
        System.out.println("Enter id to remove");
        int id=sc.nextInt();
        for(int index=0;index<studentList.size();index++) {
            student=studentList.get(index);
            if(student.getId()==id) {
                studentList.remove(student);
                System.out.println("Removed successfully");
            }
        }





    }
    private static void updatestudent(List<Student> studentList) {
        System.out.println("Enter id");
        int id=sc.nextInt();
        System.out.println("Enter name to be updated");
        String name=sc.next();
        for(int index=0;index<studentList.size();index++)
        {
            student=studentList.get(index);
            if(student.getId()==id){
                student.setName(name);
                System.out.println(student);
            }
        }
    }





    private static void searchstudent (List<Student> studentList) {
        System.out.println("Enter id");
        int id=sc.nextInt();
        for(int index=0;index<studentList.size();index++)
        {
            student=studentList.get(index);
            if(student.getId()==id) {
                System.out.println(student);
            }
        }
    }






    private static void readStudent() {
        System.out.println("Enter name");
        String name=sc.next();
        System.out.println("Enter id");
        int id=sc.nextInt();
        System.out.println("Enter marks");
        int mark=sc.nextInt();
        System.out.println("Enter branch");
        String branch=sc.next();
        student=new Student(name,id,mark,branch);
        studentList.add(student);
        System.out.println("Added successfully");
    }





}

