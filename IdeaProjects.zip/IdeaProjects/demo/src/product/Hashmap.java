package product;


import java.util.HashMap;
import java.util.Map;



public class Hashmap {
    public static void main(String args[])
    {
//Teacher teacher=new Teacher();
// Subject subject=new Subject();



        Map<Subject, Teacher> classmap=new HashMap<>();
        classmap.put(new Subject(2,"SCIENCE"),new Teacher("Manu",102));
        classmap.put(new Subject(3,"english"),new Teacher("Ganu",103));
        System.out.println(classmap);
    }
}
