package product;

public class Subject {
    int id;
    String subjectname;



    @Override
    public String toString() {
        return "Subject{" +
                "id=" + id +
                ", subjectname='" + subjectname + '\'' +
                '}';
    }
    public Subject()
    {



    }



    public Subject(int id, String subjectname) {
        this.id = id;
        this.subjectname = subjectname;
    }



    public int getId() {
        return id;
    }



    public void setId(int id) {
        this.id = id;
    }



    public String getSubjectname() {
        return subjectname;
    }



    public void setSubjectname(String subjectname) {
        this.subjectname = subjectname;
    }
}