package example;

import java.util.Scanner;
public class Exp1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number");
        int num = sc.nextInt();
        if (num < 10000) {
//1010
            int l_num = num % 10;//0
            int t_num = num / 10;//101
            int m1_num = t_num % 10;//1
            int t1_num = t_num / 10;//10
            int m2_num = t1_num % 10;//0
            int f_num = num / 1000;//1
            String ud[]={" ","One","Two","Three","Four","Five","Six","Seven","Eigth","Nine","Ten","Eleven","Twelve","Thirteen","Fourtee","Fivfteen","Sixteen","Seventeen","Eighteen","Nineteen"};
            String td[]={" ","Ten","Twenty","Thirty","Fourty","Fifty","Sixty","Sevety","Eighty","Ninety"};
            String hd="Hundred";
            String thd="Thousand";
            if(num<20)
                System.out.println(ud[num]);
            else if(num<100)
                System.out.println(td[m1_num]+" "+ud[l_num]);
            else if(num<1000)
                System.out.println(ud[f_num]+hd+" "+td[m1_num]+" "+ud[l_num]);
            else
                System.out.println(ud[f_num]+thd+" "+ud[m2_num]+hd+" "+td[m1_num]+" "+ud[l_num]);
        }
        else System.out.println("please enter upto four digits");
    }
}