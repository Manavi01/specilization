package example;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;



public class Streamexp {
    int id;
    String name;
    int marks;



    @Override
    public String toString() {
        return "Streamexp{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", marks=" + marks +
                '}';
    }



    public Streamexp(int id, String name, int marks) {
        this.id = id;
        this.name = name;
        this.marks = marks;
    }



    public int getId() {
        return id;
    }



    public void setId(int id) {
        this.id = id;
    }



    public String getName() {
        return name;
    }



    public void setName(String name) {
        this.name = name;
    }



    public int getMarks() {
        return marks;
    }



    public void setMarks(int marks) {
        this.marks = marks;
    }



    public static void main(String args[])
    {
        Streamexp s1=new Streamexp(1,"kaviya",80);
        Streamexp s2=new Streamexp(2,"Adira",85);
        Streamexp s3=new Streamexp(3,"Banu",86);
        Streamexp s4=new Streamexp(4,"Mona",80);
        Streamexp s5=new Streamexp(5,"Zella",90);
        Streamexp s6=new Streamexp(6,"Catarin",65);
        Streamexp s7=new Streamexp(7,"Farina",99);
        List<Streamexp> list = new ArrayList<Streamexp>();
        list.add(s1);
        list.add(s2);
        list.add(s3);
        list.add(s4);
        list.add(s5);
        list.add(s6);
        list.add(s7);
        List<Streamexp> Sort_by_name= list.stream().sorted(Comparator.comparing(Streamexp::getMarks).reversed()).collect(Collectors.toList());
        System.out.println(Sort_by_name);





    }
}