package com.test.Singlton1;

import com.test.Singlton1.SampleBean1;
import com.test.Singlton1.SingletonBeanConfig1;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainSingletonApp1 {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
        ctx.register(SingletonBeanConfig1.class);
        ctx.refresh();





        SampleBean1 bean1 = ctx.getBean(SampleBean1.class);
        System.out.println(bean1.hashCode());





        SampleBean1 bean2 = ctx.getBean(SampleBean1.class);
        System.out.println(bean2.hashCode());
        ctx.close();
    }
}