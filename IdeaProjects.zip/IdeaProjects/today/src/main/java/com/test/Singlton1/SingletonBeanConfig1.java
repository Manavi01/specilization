package com.test.Singlton1;

import com.test.Singlton1.SampleBean1;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;





@Configuration
public class SingletonBeanConfig1 {





    @Bean
    @Scope(value="prototype")
    public SampleBean1 getBean()
    {
        return new SampleBean1();
    }
}